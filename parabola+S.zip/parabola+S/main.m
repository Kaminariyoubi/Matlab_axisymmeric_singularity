%% Path Management
% Locate the root directory of this script and add subdirectories to the path
rootDir = fileparts(mfilename('fullpath'));
addpath(fullfile(rootDir, 'src'));
addpath(fullfile(rootDir, 'functions'));

fprintf('Starting the computation and visualization...\n');
tic;

%% 1. Load global parameters
params = config();
fprintf('Parameters loaded successfully.\n');

%% 2. Verify the time-step convergence of the solver for the ODE of S
fprintf('Verifying the time-step convergence of the solver for the ODE of S...\n');
verifyS(params);
fprintf('Verification computed.');

%% 3. Compute S, approximate solutions, and evaluate errors
fprintf('Computing S, gammas1, omegas1, and relative errors...\n');
[gammas1, omegas1, S] = compute_S(params);
fprintf('Approximate solutions computed.');

%% 4. Calculate the singularity time
Tsin = findT(params);
errT = abs((Tsin - abs(pi^2/6/params.N))/abs(pi^2/6/params.N));
fprintf('Singularity time is T = %f, and the relative error compared to the theoretical value is %f%%\n', Tsin, errT*100);

%% 5. Generate 3D surface plot for omega distribution
for t0 = (0:0.0822:0.1644)*10/abs(params.N)
    t_str = sprintf('%.4f', t0);

    fname_gamma = sprintf('figures/surface_gamma_%s_gamma_%s_omega_%s.png', t_str, params.nameg, params.nameo);
    fname_omega = sprintf('figures/surface_omega_%s_gamma_%s_omega_%s.png', t_str, params.nameg, params.nameo);

    fprintf('Generating 3D surface plot...\n');

    gamma_fig = plot_surface(gammas1, params.r, params.dt2, t0, 'gamma', 10000);
    omega_fig = plot_surface(omegas1, params.r, params.dt2, t0, 'omega', 10000);
    saveFig(gamma_fig, fname_gamma);
    saveFig(omega_fig, fname_omega);
end

%% Finished
elapsed = toc;
fprintf('\n All tasks completed successfully! Total time: %.2f seconds\n', elapsed);
fprintf('Results are stored in the workspace, and figure windows are open.\n');

function saveFig(hFig, filePath)
    if isvalid(hFig)
        mkdir(fileparts(filePath));
        exportgraphics(hFig, filePath, 'Resolution', 300);
    end
end