function [gammas1, omegas1, S1] = compute_S(params)

    Rs1 = params.R; rs1 = params.r; dt1 = params.dt2;
    S1 = convergeS(params, params.gamma0,params.r,params.R,dt1,params.step1,0);
    
    middle = log(abs((1-params.N*S1)./(1+params.N*S1)));
    dS1 = 4*params.N^2*S1.^2./( middle ).^2;
    ddS1 = 32*params.N^4*S1.^3./( middle ).^5.*(middle + 2*params.N*S1./(1 - params.N^2*S1.^2));
    
    gammas1 = zeros(length(S1), length(rs1));
    gammas1(1,:) = params.gamma0;
    omegas1 = zeros(length(S1), length(rs1));
    omegas1(1,:) = params.omega0;
    
    testn = round((length(S1)/params.step1)*0.02055 * (1:8));
    
    for iT = 1:8
        it = round(testn(iT))+1;
        for ir = 1:length(rs1)
            term = 2*gammas1(1,1)*S1(it)*rs1(ir).^2./sqrt(dS1(it))/Rs1^2;
            gammas1(it,ir) = -dS1(it)./S1(it)./(1+gammas1(1,1)*S1(it)) .* exp(term) ...
                           + dS1(it)./S1(it) - ddS1(it)./dS1(it)/2;
            omegas1(it,ir) = omegas1(1,ir)*(1+gammas1(1,1)*S1(it))./sqrt(dS1(it))./exp(term);
        end
    end
end