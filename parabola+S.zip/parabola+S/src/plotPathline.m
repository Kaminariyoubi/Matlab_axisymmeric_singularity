function [rr2, tlist] = plotPathline(params, omega, rr0, tt0, zz0, color0)

S2 = convergeS(params,params.gamma0,params.r,params.R,params.dt2,params.step1,0);

%ds2 = [S2(2) - S2(1), (- S2(1:end-2) + S2(3:end))/2, S2(end) - S2(end-1)]/0.00001;

middle = log(abs((1-params.N*S2)./(1+params.N*S2)));
ds2 = 4*params.N^2*S2.^2./( middle ).^2;

%omega = 300;
%rr2 = ds2.^(1/4)./sqrt(2*S2) .* sqrt( 0.1*log( abs( 1 - 2*(-10)*S2*rr0^2./(1 - 10*S2) ) ) );

rr2 = sqrt(-ds2.^(1/2)*params.R^2/2/params.N./S2.*log( abs(1 - 2*params.N*S2*rr0^2./params.R^2./(1 + params.N*S2) )));


posr = round(rr0/params.dr);
% 
% rr2 = ones(length(S2),1)*rr0;
% for i = 1:length(S2)
%     rr2(i) = ds2(i).^(1/4) .* sqrt( sum(simpson( params.r./(1 + params.gamma0*S2(i)), params.r, params.r(1:posr-1), params.r(2:posr))) );
% end

tlist = 0:params.dt2:0.16448;
inte2 = rr2.^(-2);

tt2 = zeros(length(tlist));
tt2(1) = tt0;

for i=2:length(tlist)
    %tt2(i) = tt0 + 2*10*( rr0*omega )* sum(inte2(2:i))*params.dt2;
    tt2(i) = tt0 + 1/2*( rr0^2*omega )* sum(inte2(2:i))*params.dt2;
end

%zz2 = 2*10*S2*zz0./sqrt(ds2) + zz0*(1 - 10*S2)./sqrt(ds2);
zz2 = zz0 * (1 + params.gamma0(posr)*S2)./sqrt(ds2);

x2 = rr2(2:length(tlist)) .* cos(tt2(2:length(tlist)));

y2 = rr2(2:length(tlist)) .* sin(tt2(2:length(tlist)));


plotn = 100;
refn = floor((length(tlist)-1)/plotn);

for tplot = 1:plotn
    plot3(x2((1+(tplot-1)*refn):(tplot*refn)), y2((1+(tplot-1)*refn):(tplot*refn)), zz2((2+(tplot-1)*refn):(1+tplot*refn)), 'b-', 'LineWidth', (1-(tplot-1)/plotn)*4+2, 'Color', color0);
    hold on
end

% quiver3(x2(end-10), y2(end-10), tlist(end-10), ...
%         x2(end)-x2(end-10), y2(end)-y2(end-10), tlist(end)-tlist(end-10), ...
%         0, 'Color', 'g', 'LineWidth', 2);

fontsize = 25;

set(gca, 'Visible', 'on', 'FontSize', fontsize);        % 隐藏坐标轴
xlabel('x', 'FontSize', fontsize);
ylabel('y', 'FontSize', fontsize);
zlabel('z', 'FontSize', fontsize);
pbaspect([1 1 1]);

set(gcf, 'Position', [100, 100, 900, 800]);  % 增大 figure
set(gca, 'Position', [0.12, 0.08, 0.75, 0.7]);  % 调整 axes 位置
%axis off;                          % 彻底关闭坐标轴显示
%axis equal;                        % 保持比例
%view(3);                           % 3D视角
%camlight; lighting gouraud;        % 添加光照，使圆柱更立体
box on;
%axis off        % 关闭坐标轴（包括三轴、刻度、标签）

%set(gcf, 'Color', 'black');