rootDir = fileparts(mfilename('fullpath'));
addpath(fullfile(rootDir, 'src'));
addpath(fullfile(rootDir, 'functions'));

tic;

index = 1; % 1 for -10*(-2*r^2+1), 2 for 10*(-2*r^2+1)

omegalist = [380, 88];

params = config();
params.N = (2*index-3)*10;
params.gamma0 = params.N*(-2*params.r.^2 + 1);
%params.gamma0 = params.N*(-2*params.r.^2 + 1);
%params.gamma0 = params.N*(2*params.r.^2 - 4*params.r + 1);

di = 0.7;

for i = 0:di:(1-di)
    [rr21, tt21] = plotPathline(params, omegalist(index), 0.25, i*2*pi+2+pi, 0.4, [1 0 0]);
    %[rr21, tt21] = plotPathline(params, omegalist(index), 0.25, 0, 0.4, [1 0 0]);
    hold on
end 

for i = 0:di:(1-di)
    [rr22, tt22] = plotPathline(params, omegalist(index), 0.6, i*2*pi+pi-0.6, 0.1, [0 0 1]);
    %plotPathline(params, 0.7072, i*2*pi+1.2, 0.1, [0 0 1])
    hold on
end


for i = 0:di:(1-di)
    [rr23, tt23] = plotPathline(params, omegalist(index), 0.4, i*2*pi+1+0.2, 0.9, [0 1 0]);
    %plotPathline(params, 0.7, i*2*pi+1+0.2, 0.1, [0 1 0])
    hold on
end

newview = 20;

set(gcf, 'Color', 'white')
view(105, index*(25 - newview) + 2*newview - 25)

