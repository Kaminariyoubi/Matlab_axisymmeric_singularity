%% ================= Time-step convergence test =================

function verifyS(params)

rootDir = fileparts(mfilename('fullpath'));
addpath(fullfile(rootDir, 'src'));
addpath(fullfile(rootDir, 'functions'));

fprintf('=== Starting Convergence Verification for S ===\n');
tic;

n_levels = 5;               % Number of \Delta t
r_ref = 2;                  % Refinement ratio
est_ratio = 0.1:0.1:1;      % Check-point time [10%, 20%, ..., 100%]
n_checks = length(est_ratio);

S_sol = cell(n_levels, 1);
S_diff = cell(n_levels-1, 1);
dt_vals = zeros(n_levels, 1);

for i = 1:n_levels 
    params.dt2 = params.dtconv1 * (r_ref^(1-i));
    dt_vals(i) = params.dt2;
    
    fprintf('\n[Level %d] dt=%.2e ... ', i, params.dt2);
    
    % ================= Computation =================
    dt_s = params.dt2;
    S1 = convergeS(params, params.gamma0, params.r, params.R, dt_s, params.step1, 0);

    if i > 1
        S_diff{i-1} = abs(S1(floor(est_ratio*length(S1)))./S2(floor(est_ratio*length(S2))) - 1);
    end

    S2 = S1;
end

colors = lines(n_checks);

for i = 1:length(est_ratio)
    xs = zeros(length(S_diff),1);
    for j = 1:length(S_diff)
        xs(j) = S_diff{j}(i);
    end
    plot(dt_vals(2:end), xs, '-o', 'Color', colors(i,:), ...
        'LineWidth', 2, 'MarkerSize', 7, ...
        'DisplayName', sprintf('S @ %.0f%% T', est_ratio(i)*100))
    hold on
end

xlabel('\Delta t', 'FontSize', 12);
ylabel('Relative Error |1 - S_{\Delta t}/S_{2\Delta t}|', 'FontSize', 12);
title('Multi-Checkpoint Time Step Convergence', 'FontSize', 14);
legend('Location', 'northwest', 'FontSize', 10);
hold off;
