function params = config()
    params.R = 1;
    params.dr = 0.001;
    params.r = 0:params.dr:params.R;

    params.N = 10;    
    params.gamma0 = params.N*(-2*params.r.^2 + 1);
%    params.gamma0 =     params.N*(2*params.r.^2 - 4*params.r + 1);
    params.nameg = "20r^2-10";
    params.omega0 = ones(1, length(params.r))*10;
    params.nameo = "10";
    
    params.t_switch = 0.16449;          % 切换步长/精度的时间节点
    params.dt2 = 1e-4/abs(params.N);

    params.dtconv1 = 1e-4/abs(params.N);
    params.dtconv2 = 1e-4/abs(params.N);

    params.step1 = pi^2/6/abs(params.N)*1.01; params.sep = 0.9;

    params.di = 0.1;
    % ... 其他参数
end