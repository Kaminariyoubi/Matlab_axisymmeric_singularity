function T = findT(params)

dS = 1e-6;
dSfine = 1e-10;

Sstar = -1/min(params.gamma0);

Sold = 0:dS:Sstar;
Sfine = (Sstar-dS):dSfine:(Sstar-dSfine);

S = Sold(1:end-1);

N = params.N;

inte0 = 1/4/N^2./(S.^2).*( log( (1 - N*S)./(1 + N*S) ) ).^2;
intefine = 1/4/N^2./(Sfine.^2).*( log( (1 - N*Sfine)./(1 + N*Sfine) ) ).^2;

T0 = sum(simpson(inte0, S, S(1:end-1), S(2:end)));
Tfine = sum(simpson(intefine, Sfine, Sfine(1:end-1), Sfine(2:end)));
T = T0+Tfine;