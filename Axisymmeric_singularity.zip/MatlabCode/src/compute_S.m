function [gammas1, omegas1, testT, errgm, errwm] = compute_S(params, gamma2, omega2, gamma3, omega3)

    Rs1 = params.R; N = params.N; dt1 = params.dt2;
    [y1, rs1, ~, ~] = convergeS(params.gamma0,params.r,params.R,dt1,params.step1,0);
    dr1 = rs1(2)-rs1(1);
    gm1 = min(params.gamma0);
    S1 = -1/gm1*(1-exp(y1));
    dS1 = centralDiff(S1, dt1);
    ddS1 = centralDiff(dS1, dt1);
    
    gammas1 = zeros(length(S1), length(rs1));
    gammas1(1,:) = params.gamma0;
    omegas1 = zeros(length(S1), length(rs1));
    omegas1(1,:) = params.omega0;
    
    testn = round((length(S1)/params.step1)*0.02055 * (1:8));
    testT = testn*dt1;
    errgm = zeros(8,1); errwm = zeros(8,1);
    
    for iT = 1:8
        it = round(testn(iT))+1;
        for ir = 1:length(rs1)
            term = 2*gammas1(1,1)*S1(it)*rs1(ir).^2./sqrt(dS1(it))/Rs1^2;
            gammas1(it,ir) = -dS1(it)./S1(it)./(1+gammas1(1,1)*S1(it)) .* exp(term) ...
                           + dS1(it)./S1(it) - ddS1(it)./dS1(it)/2;
            omegas1(it,ir) = omegas1(1,ir)*(1+gammas1(1,1)*S1(it))./sqrt(dS1(it))./exp(term);
        end
 
        if it*params.dt2/params.dt1 <= length(gamma2)
            idx2 = max(1, round(it*params.dt2/params.dt1));
            errgm(iT) = norm(gamma2(idx2,:) - gammas1(it,:))/norm(gamma2(idx2,:));
            errwm(iT) = norm(omega2(idx2,:) - omegas1(it,:))/norm(omega2(idx2,:));
        else
            idx3 = max(1, round((it*params.dt2/params.dt1-params.sep/params.dt1*params.step1)*params.dt1/params.dt2));
            errgm(iT) = norm(gamma3(idx3,:) - gammas1(it,:))/norm(gamma3(idx3,:));
            errwm(iT) = norm(omega3(idx3,:) - omegas1(it,:))/norm(omega3(idx3,:));
        end
    end
end