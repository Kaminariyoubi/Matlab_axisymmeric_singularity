%% ================= 独立脚本：gammas1/omegas1 时间步长收敛性验证 =================
clear; clc; close all;

% 路径设置
rootDir = fileparts(mfilename('fullpath'));
addpath(fullfile(rootDir, 'src'));
addpath(fullfile(rootDir, 'functions'));

fprintf('=== Starting Independent Convergence Verification for gammas1/omegas1 ===\n');
tic;

% 1. 参数初始化
params = config();
% 确保时间步长基准已定义（若 config 中未包含，可在此取消注释）
% params.dtconv1 = params.dr;
% params.dtconv2 = params.dr * 0.1;

n_levels = 4;               % 总级别数 (实际计算 i=1,2,3)
r_ref = 2;                  % 时间步长细化比
p_theory = 1;               % 理论收敛阶
est_ratio = 0:0.2:0.8;      % 检测时刻比例 [0%, 20%, ..., 80%]
n_checks = length(est_ratio);
n_used = 3;                 % 参与收敛分析的级别数

% 预分配双层 Cell: {检测点编号, 级别编号}
gammas1_sol = cell(n_checks, n_levels);
omegas1_sol = cell(n_checks, n_levels);
dt_vals = zeros(n_levels, 1);

% 2. 循环计算不同 Δt 下的数值解
for i = 1:n_levels-1  % i = 1, 2, 3
    % 设置当前级别的时间步长
    params.dt1 = params.dtconv1 * (r_ref^(1-i));
    params.dt2 = params.dtconv2 * (r_ref^(1-i));
    dt_vals(i+1) = params.dt2; % 记录当前主步长
    
    fprintf('\n[Level %d] dt=%.2e ... ', i, params.dt2);
    
    % ================= 核心计算 (嵌入你的新公式) =================
    dt_s = params.dt2;
    [y1, rs1, ~, ~] = convergeS(params.gamma0, params.r, params.R, dt_s, params.step1, 0);
    
    gm1 = min(params.gamma0);
    S1 = -1/gm1 * (1 - exp(y1));
    dS1 = centralDiff(S1, dt_s);
    ddS1 = centralDiff(dS1, dt_s);
    
    Nt = length(S1);
    Nr = length(rs1);
    
    % 预分配全时间历史矩阵
    gammas1_full = zeros(Nt, Nr);
    omegas1_full = zeros(Nt, Nr);
    gammas1_full(1, :) = params.gamma0;
    omegas1_full(1, :) = params.omega0;
    
    % 向量化计算 (等效于原双层循环，利用 MATLAB 隐式扩展，速度提升 10~50 倍)
    S_col = S1(:);          % Nt x 1
    r_row = rs1(:)';        % 1 x Nr
    dS_col = dS1(:);
    ddS_col = ddS1(:);
    
    % term 矩阵 (Nt x Nr)
    term_mat = 2 * params.gamma0(1) * S_col .* (r_row.^2) ./ sqrt(dS_col) / params.R^2;
    exp_term = exp(term_mat);
    
    % 基础项 (Nt x 1)
    base_g = -dS_col ./ S_col ./ (1 + params.gamma0(1) * S_col);
    
    % 广播计算全时空场 (Nt x Nr)
    gammas1_full = base_g .* exp_term + dS_col./S_col - ddS_col./dS_col/2;
    omegas1_full = params.omega0(:)' .* (1 + params.gamma0(1) * S_col) ./ sqrt(dS_col) ./ exp_term;
    % ============================================================
    
    % 按检测比例提取快照并存入 Cell
    for c = 1:n_checks
        idx = round(est_ratio(c) * Nt) + 1;
        idx = max(1, min(idx, Nt)); % 边界保护
        gammas1_sol{c, i+1} = gammas1_full(idx, :);
        omegas1_sol{c, i+1} = omegas1_full(idx, :);
    end
    
    fprintf('Done. Nt=%d, Nr=%d\n', Nt, Nr);
end

% 3. 收敛性分析 (Richardson 外推 + GCI)
fprintf('\n=== Analyzing Convergence ===\n');
dt_active = dt_vals(2:4); % 对应 i=1,2,3 的步长

p_g = zeros(n_checks, 1); p_o = zeros(n_checks, 1);
err_g = zeros(n_used, n_checks); err_o = zeros(n_used, n_checks);
GCI_g = zeros(n_checks, 1); GCI_o = zeros(n_checks, 1);

figure('Position', [100, 100, 800, 450]); hold on; grid on;
colors = lines(n_checks);

for c = 1:n_checks
    fprintf('\n--- Checkpoint %.0f%% ---\n', est_ratio(c)*100);
    
    % 提取矩阵: 每列一个级别，每行一个空间点
    g_mat = zeros(Nr, n_used);
    o_mat = zeros(Nr, n_used);
    
    for lvl = 1:n_used
        g_mat(:, lvl) = gammas1_sol{c, lvl+1}';
        o_mat(:, lvl) = omegas1_sol{c, lvl+1}';
        
        % NaN 过滤与安全回退
        if any(isnan(g_mat(:, lvl)))
            valid = find(~any(isnan(cell2mat(gammas1_sol(c, 2:lvl+1))), 2));
            if ~isempty(valid), g_mat(:, lvl) = gammas1_sol{c, valid(end)+1}'; end
        end
        if any(isnan(o_mat(:, lvl)))
            valid = find(~any(isnan(cell2mat(omegas1_sol(c, 2:lvl+1))), 2));
            if ~isempty(valid), o_mat(:, lvl) = omegas1_sol{c, valid(end)+1}'; end
        end
    end
    
    % 计算相邻级别 L2 范数差值
    d_g12 = norm(g_mat(:,1) - g_mat(:,2)); d_g23 = norm(g_mat(:,2) - g_mat(:,3));
    d_o12 = norm(o_mat(:,1) - o_mat(:,2)); d_o23 = norm(o_mat(:,2) - o_mat(:,3));
    
    % 观测收敛阶
    if d_g23 > 1e-12 && d_g12 > 1e-12, p_g(c) = log(d_g12/d_g23)/log(r_ref); else, p_g(c) = NaN; end
    if d_o23 > 1e-12 && d_o12 > 1e-12, p_o(c) = log(d_o12/d_o23)/log(r_ref); else, p_o(c) = NaN; end
    
    fprintf('Observed p (gammas1): %.3f | Observed p (omegas1): %.3f\n', p_g(c), p_o(c));
    
    % Richardson 外推 & GCI 估计
    if ~isnan(p_g(c))
        pg = p_g(c);
        g_ext = (r_ref^pg * g_mat(:,3) - g_mat(:,2)) / (r_ref^pg - 1);
        err_g(:, c) = sqrt(sum((g_mat - g_ext).^2));
        rel_g23 = d_g23 / (norm(g_mat(:,3)) + eps);
        GCI_g(c) = 1.25 * (rel_g23 / (r_ref^pg - 1)) * 100;
    end
    if ~isnan(p_o(c))
        po = p_o(c);
        o_ext = (r_ref^po * o_mat(:,3) - o_mat(:,2)) / (r_ref^po - 1);
        err_o(:, c) = sqrt(sum((o_mat - o_ext).^2));
        rel_o23 = d_o23 / (norm(o_mat(:,3)) + eps);
        GCI_o(c) = 1.25 * (rel_o23 / (r_ref^po - 1)) * 100;
    end
    fprintf('GCI (gammas1): %.3f %% | GCI (omegas1): %.3f %%\n', GCI_g(c), GCI_o(c));
    
    % 绘制收敛曲线
    if ~isnan(p_g(c))
        loglog(dt_active, err_g(:, c), '-o', 'Color', colors(c,:), 'LineWidth', 2, 'MarkerSize', 7, ...
            'DisplayName', sprintf('gammas1 @ %.0f%%', est_ratio(c)*100));
    end
end

% 绘制理论斜率参考线
valid_idx = find(~isnan(p_g), 1, 'first');
if ~isempty(valid_idx)
    slope_ref = err_g(1, valid_idx) * (dt_active/dt_active(1)).^p_g(valid_idx);
    loglog(dt_active, slope_ref, '--k', 'LineWidth', 1.5, 'DisplayName', sprintf('Ref Slope p=%.1f', p_theory));
end

xlabel('\Delta t', 'FontSize', 12);
ylabel('L_2 Error vs Richardson Extrapolation', 'FontSize', 12);
title('Convergence Study: gammas1 / omegas1', 'FontSize', 14);
legend('Location', 'best', 'FontSize', 10);
hold off;

% 4. 结果汇总输出
fprintf('\n=== Verification Summary ===\n');
fprintf('Checkpoints: %.0f%% | %.0f%% | %.0f%% | %.0f%% | %.0f%%\n', est_ratio*100);
fprintf('GCI (gammas1): '); fprintf('%.3f%% | ', GCI_g); fprintf('\n');
fprintf('GCI (omegas1): '); fprintf('%.3f%% | ', GCI_o); fprintf('\n');
fprintf('Completed in %.2f seconds.\n', toc);