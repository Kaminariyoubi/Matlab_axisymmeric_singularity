function [gamma2, gamma3, T] = compute_gamma(params)
    R1 = params.R;
    dr1 = params.dr;
    r1 = 0:dr1:R1;
    dtg1 = params.dt1;
    dtg2 = params.dt2;
    estT1 = params.step1;
    sep = params.sep;
    gamma0 = params.gamma0;
%    omega0 = params.omega0;

    Nsep = floor(estT1/dtg1*sep);
    estT2 = estT1*(1-sep);
    

    [gamma2, r2, dt2, Tg2] = basicRadial(gamma0, R1, dr1, estT1, dtg1);
    [gamma3, r3, dt3, Tg3] = basicRadial(gamma2(Nsep, :), R1, dr1, estT2, dtg2);
    T = Nsep * dtg1 + Tg3;
end