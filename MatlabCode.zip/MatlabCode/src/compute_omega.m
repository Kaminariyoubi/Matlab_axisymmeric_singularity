function [omega2, omega3, T] = compute_omega(params, gamma2, gamma3)
    R1 = params.R;
    dr1 = params.dr;
    r1 = 0:dr1:R1;
    dtg1 = params.dt1;
    dtg2 = params.dt2;
    estT1 = params.step1;
    sep = params.sep;
%    gamma0 = params.gamma0;
    omega0 = params.omega0;

    Nsep = floor(estT1/dtg1*sep);
    estT2 = estT1*(1-sep);
%(1:Nsep, :)
    [omega2, r2, dt2, To2] = omegaRadial(gamma2, omega0, R1, dr1, estT1, dtg1);
    [omega3, r3, dt3, To3] = omegaRadial(gamma3, omega2(Nsep, :), R1, dr1, estT2, dtg2);
    T = Nsep * dtg1 + To3;
end