function fig = plot_surface(omegas1, rs1, dts, t0, ty, Ntheta)
% PLOT_SURFACE  绘制三维分布曲面图并返回 Figure 句柄

    % 1. 提取当前时刻数据 (+1 是因为 MATLAB 索引从 1 开始)
    gammas = omegas1(int32(t0/dts)+1, :);

    % 2. 构建网格
    [rr, theta] = meshgrid(rs1, linspace(0, 2*pi, Ntheta));
    X = rr .* cos(theta);
    Y = rr .* sin(theta);
    Z = repmat(gammas, Ntheta, 1);

    % --- 核心修复 ---
    fig = figure;  % 显式创建 Figure 对象并获取句柄（原代码此处返回的是 Surface 对象，导致导出报错）
    mesh(X, Y, Z); % 在当前的 fig 中绘图

    % 3. 属性设置（使用 fig 变量替代 gcf，更加稳健且避免多窗口干扰）
    set(fig, 'Position', [100, 100, 900, 600]);
    set(fig, 'Color', 'none');
    
    if ty == 'gamma'
        tyname = '\gamma';
    elseif ty == 'omega'
        tyname = '\omega';
    end

    % 4. 标签与视图
    xlabel('x', 'HorizontalAlignment','center','FontSize', 50, 'FontName', 'Times New Roman');
    ylabel('y', 'HorizontalAlignment','center','FontSize', 50, 'FontName', 'Times New Roman');
    zlabel(tyname, 'FontSize', 50, 'FontName', 'Times New Roman');
    set(gca, 'FontSize', 40, 'FontName', 'Times New Roman');

    t_str = sprintf('%.4f', t0);
    title(sprintf('t = %s', t_str));
    colormap(flip(colormap('jet')));
    view(60, 30);
end