function gammaR = dgdt(gamma0, R, dr)

r = 0:dr:R;

dgdr = centralDiff(gamma0, dr);
avg = 2/R^2*sum(simpson(gamma0.^2.*r, r, r(1:end-1), r(2:end)));
g2 = gamma0.^2;
ur = [0, -1./r(2:end).*cumsum(simpson(gamma0.*r, r, r(1:end-1), r(2:end)))];

gammaR = 2*avg - g2 - ur.*dgdr;










