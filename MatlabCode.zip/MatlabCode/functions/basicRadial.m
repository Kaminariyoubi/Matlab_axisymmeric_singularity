function [gammaR, r, dt, Tt] = basicRadial(gamma0, R, dr, T, dt)

r = 0:dr:R;
t = 0:dt:T;

gamma1 = gamma0;
fprintf('\nStart the RK computation:      \n');
for i = 1:length(t)
    gamma2 = [gamma1; RK_basicRadial(gamma1(i, :), R, dr, dt)];
    gamma1 = gamma2;
    Ti = i;
    fprintf('\b\b\b\b\b\b\b%6.2f%%', i/length(t)*100);
    if any(isnan(gamma1(end, :)))
        break;
    end
end
fprintf('\nDone!\n');
gammaR = gamma1;
Tt = (Ti - 1)*dt;

