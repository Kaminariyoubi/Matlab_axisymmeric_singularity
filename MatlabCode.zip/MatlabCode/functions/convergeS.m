function [output, r4, dt, T] = convergeS(zeta4, r4, R4, dt, Ttest, S0)

%zeta4 = (2/( (1-r0)^nup/ndown + r0^nup/ndown ) * ((r4 - r0).^(nup)).^(1/ndown) - 1)*N;

%gm1 = min(zeta4);
%zeta4 = gammaS(nup, ndown, r4, r0, N);

num_step = int64(Ttest/dt);
Slist = zeros(1, num_step);
%dS = zeros(1, num_step);
%ddS = zeros(1, num_step);

T = Ttest;
Slist(1) = S0;
%dS(1) = 1;
%ddS(1) = 0;

fprintf('\nStart the S computation:      \n');
for i = 2:num_step
    Slist(i) = rk4_step(zeta4, R4, r4, Slist(i-1), dt);
%    trueS = -1/gm1*(1 - exp(Slist(i)));
%    dS(i) = R4^2/4*(sum(simpson(r4./(1 + zeta4.*trueS), r4, r4(1:end-1), r4(2:end)))).^(-2);
%    ddS(i) = 2*dS(i).^(5/2)*2/R4*(sum(simpson(zeta4.*r4./(1 + zeta4.*trueS).^2, r4, r4(1:end-1), r4(2:end))));
    fprintf('\b\b\b\b\b\b\b%6.2f%%', (i-1)/(num_step-1)*100.0);
    if any(isnan(Slist(i)))
        T = i*dt;
        break;
    end
end
output = Slist;


fprintf('\nDone!\n');

end