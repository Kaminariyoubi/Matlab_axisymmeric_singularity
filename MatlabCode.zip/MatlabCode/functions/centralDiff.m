function df = centralDiff(f, dx)

df = [(f(2)-f(1))/dx, (f(3:end) - f(1:end-2))/2/dx, (f(end) - f(end-1))/dx];
