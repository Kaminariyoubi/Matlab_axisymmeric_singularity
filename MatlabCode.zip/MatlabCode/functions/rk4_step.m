function S_new = rk4_step(gamma, R, r, S, dt)
    
    k1 = F(S, gamma, R, r);
    k2 = F(S + dt/2 * k1, gamma, R, r);
    k3 = F(S + dt/2 * k2, gamma, R, r);
    k4 = F(S + dt * k3, gamma, R, r);
    
    S_new = S + dt/6 * (k1 + 2*k2 + 2*k3 + k4);
end

function ode = F(S, gamma, R, r)

    %ode = (2/R^2*sum(r./(1 + gamma*S)*(r(2) - r(1)))).^(-2);
    %ode = -exp(-S) .* (2/R^2*sum(r./(1 + gamma*(1 - exp(S)))*(r(2) - r(1)))).^(-2);
    inte = r./(1 - gamma/min(gamma)*(1 - exp(S)));
    ode = min(gamma) * exp(-S) .* (2/R^2*( (inte(1) + 4*sum(inte(2:2:end)) + 2*sum(inte(3:2:end-1)) + inte(end))/3 )*(r(2) - r(1))).^(-2);

end

