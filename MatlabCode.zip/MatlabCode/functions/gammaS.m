function zeta4 = gammaS(nup, ndown, r4, r0, N)

zeta4 = (2/( (1-r0)^(nup/ndown) + r0^(nup/ndown) ) * ((r4 - r0).^(nup)).^(1/ndown) - 1)*N;