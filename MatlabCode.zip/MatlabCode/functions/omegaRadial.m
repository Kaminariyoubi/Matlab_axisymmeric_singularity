function [omegaR, r, dt, Tt] = omegaRadial(gammalist, omega0, R, dr, T, dt)

r = 0:dr:R;
t = 0:dt:T;

omega1 = log(omega0);
fprintf('\nStart the RK computation for omega:      \n');
for i = 1:length(gammalist)
    omega2 = [omega1; RK_omegaRadial(gammalist(i,:), omega1(i, :), R, dr, dt)];
    omega1 = omega2;
    Ti = i;
    fprintf('\b\b\b\b\b\b\b%6.2f%%', i/length(t)*100);
    if any(isnan(omega1(end, :)))
        break;
    end
end
fprintf('\nDone!\n');
omegaR = exp(omega1);
Tt = (Ti - 1)*dt;

% function [omegaR, r, dt, Tt] = omegaRadial(gammalist, omega0, R, dr, T, dt)
% % OMEGARADIAL  半拉格朗日法求解 d(ln w)/dt + ur*d(ln w)/dr = gamma
% %   彻底消除空间离散误差，天然保持 w>0，无 CFL 限制。
% %
% %   Input:
% %     gammalist : Nt x Nr 矩阵，每行为当前时刻的 gamma(r) 场
% %     omega0    : 1 x Nr 向量，初始 omega 场
% %     R, dr     : 计算域半径与网格步长
% %     T, dt     : 总时间与时间步长
% %   Output:
% %     omegaR    : (Nt+1) x Nr 矩阵，欧拉网格上的 omega 演化历史
% %     r, dt, Tt : 网格、步长、实际计算总时间
% 
%     r = 0:dr:R;
%     Nt = size(gammalist, 1);  % 实际时间步数
% 
%     % 预分配内存，提升性能
%     omegaR = zeros(Nt+1, length(r));
%     omegaR(1, :) = omega0;
% 
%     % 初始对数场
%     theta = log(omega0);
% 
%     fprintf('\nStart computation for omega:\n');
%     for i = 1:Nt
%         gamma_curr = gammalist(i, :);
% 
%         %% 1. 计算当前径向速度 ur(r)
%         % 物理关系: ur = -(1/r) * ∫₀ʳ γ·r' dr'
%         integral_gamma = cumtrapz(r, gamma_curr .* r);
%         ur = integral_gamma ./ r;
%         ur(1) = 0;  % r→0 处由对称性保证 ur=0
% 
%         %% 2. 半拉格朗日追踪：反向找特征线起点
%         r_star = r - ur * dt;
% 
%         % 边界截断处理（防止浮点误差越界）
%         r_star = max(r(1), min(r(end), r_star));
% 
%         %% 3. 空间插值：获取起点处的 theta 与 gamma
%         % pchip 保形插值：避免 spline 的非物理振荡，更适合对数场
%         theta_star = interp1(r, theta, r_star, 'pchip', 'extrap');
%         gamma_star = interp1(r, gamma_curr, r_star, 'pchip', 'extrap');
% 
%         %% 4. 沿特征线精确积分源项: d(theta)/dt = gamma
%         % 一阶显式更新。若需二阶精度，可改为中点法：
%         % gamma_mid = 0.5*(gamma_star + interp1(r, gamma_curr, r, 'pchip'));
%         % theta_new = theta_star + gamma_mid * dt;
%         gamma_mid = 0.5 * (gamma_star + interp1(r, gamma_curr, r_star + 0.5*ur*dt, 'pchip', 'extrap'));
%         theta_new = theta_star + gamma_mid * dt;
% 
%         %% 5. 边界条件修正（根据你的物理问题取消注释并修改）
%         % theta_new(1)   = 0;           % r=0 对称性
%         % theta_new(end) = theta(end);  % 外边界 Neumann/Dirichlet
% 
%         theta = theta_new;
%         omegaR(i+1, :) = exp(theta);
% 
%         % 进度提示
%         fprintf('\b\b\b\b\b\b\b%6.2f%%', i/Nt*100);
% 
%         % 稳定性检查
%         if any(isnan(omegaR(i+1, :))) || any(isinf(omegaR(i+1, :)))
%             warning('NaN/Inf detected at step %d. Stopping early.', i);
%             Tt = (i-1)*dt;
%             omegaR = omegaR(1:i, :);
%             break;
%         end
%     end
%     fprintf('\nDone!\n');
%     Tt = (min(i, Nt)) * dt;
% end