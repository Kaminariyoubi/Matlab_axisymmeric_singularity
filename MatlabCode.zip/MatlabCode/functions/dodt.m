function omegaR = dodt(gamma0, omega0, R, dr)

r = 0:dr:R;

dodr = centralDiff(omega0, dr);
ur = [0, -1./r(2:end).*cumsum(simpson(gamma0.*r, r, r(1:end-1), r(2:end)))];
% integral_gamma = cumtrapz(r, gamma0 .* r);
% ur = integral_gamma ./ r;
% ur(1) = 0;

omegaR = gamma0 - ur.*dodr;










