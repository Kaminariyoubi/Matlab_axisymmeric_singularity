function gammaR = RK_basicRadial(gamma0, R, dr, dt)

k1 = dgdt(gamma0, R, dr);
k2 = dgdt(gamma0 + dt*k1/2, R, dr);
k3 = dgdt(gamma0 + dt*k2/2, R, dr);
k4 = dgdt(gamma0 + dt*k3, R, dr);

gammaR = gamma0 + dt/6*( k1 + 2*k2 + 2*k3 + k4 );