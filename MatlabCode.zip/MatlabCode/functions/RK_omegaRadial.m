function omegaR = RK_omegaRadial(gamma0, omega0, R, dr, dt)

k1 = dodt(gamma0, omega0, R, dr);
k2 = dodt(gamma0, omega0 + dt*k1/2, R, dr);
k3 = dodt(gamma0, omega0 + dt*k2/2, R, dr);
k4 = dodt(gamma0, omega0 + dt*k3, R, dr);

omegaR = omega0 + dt/6*( k1 + 2*k2 + 2*k3 + k4 );