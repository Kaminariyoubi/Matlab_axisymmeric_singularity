function piece = simpson(f, x, alist, blist)

if isnan(f)
    g = f;
    g(isnan(g)) = Inf;
    piece = (blist - alist)/6.*( spline(x, g, alist) + spline(x, g, blist) + 4*spline(x, g, (alist+blist)/2) );
else
    piece = (blist - alist)/6.*( spline(x, f, alist) + spline(x, f, blist) + 4*spline(x, f, (alist+blist)/2) );
end

