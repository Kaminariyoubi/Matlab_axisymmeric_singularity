rr0 = 0.2;
tt0 = 0.5;
zz0 = 0.1;
color0 = [1, 0, 0];

S2 = 0.1*(1 - exp(convergeS(params.gamma0,params.r,params.R,params.dt2,params.step1,0)));

ds2 = [S2(2) - S2(1), (- S2(1:end-2) + S2(3:end))/2, S2(end) - S2(end-1)]/0.00001;

omega = 0.4;
%rr2 = ds2.^(1/4)./sqrt(2*S2) .* sqrt( 0.1*log( abs( 1 - 2*(-10)*S2*rr0^2./(1 - 10*S2) ) ) );

if params.N < 0
    rr2 = sqrt(-ds2.^(1/4)/4/params.N./S2.*log( 1 - 2*params.N*S2*rr0^2./(1 + params.N*S2) ));
else
    rr2 = sqrt(ds2.^(1/4)/4/params.N./S2.*log( 1./(1 - 2*params.N*S2*rr0^2./(1 + params.N*S2)) ));
end

posr = round(rr0/params.dr);
% 
% rr2 = ones(length(S2),1)*rr0;
% for i = 1:length(S2)
%     rr2(i) = ds2(i).^(1/4) .* sqrt( sum(simpson( params.r./(1 + params.gamma0*S2(i)), params.r, params.r(1:posr-1), params.r(2:posr))) );
% end

tlist = 0:0.00001:0.16448;
inte2 = rr2.^(-2);

tt2 = zeros(length(tlist));
tt2(1) = tt0;

for i=2:length(tlist)
    tt2(i) = tt0 + 2*10*( rr0*omega )* sum(inte2(2:i))*params.dt2;
end

%zz2 = 2*10*S2*zz0./sqrt(ds2) + zz0*(1 - 10*S2)./sqrt(ds2);
zz2 = zz0 * (1 + params.gamma0(posr)*S2)./sqrt(ds2);

x2 = rr2(2:length(tlist)) .* cos(tt2(2:length(tlist)));

y2 = rr2(2:length(tlist)) .* sin(tt2(2:length(tlist)));


plotn = 100;
refn = floor((length(tlist)-1)/plotn);

for tplot = 1:plotn
    plot3(x2((1+(tplot-1)*refn):(tplot*refn)), y2((1+(tplot-1)*refn):(tplot*refn)), zz2((2+(tplot-1)*refn):(1+tplot*refn)), 'b-', 'LineWidth', (1-(tplot-1)/plotn)*4, 'Color', color0);
    hold on
end

quiver3(x2(end-10), y2(end-10), tlist(end-10), ...
        x2(end)-x2(end-10), y2(end)-y2(end-10), tlist(end)-tlist(end-10), ...
        0, 'Color', 'g', 'LineWidth', 2);

set(gca, 'Visible', 'on', 'FontSize', 18);        % 隐藏坐标轴
xlabel('x', 'FontSize', 18);
ylabel('y', 'FontSize', 18);
zlabel('z', 'FontSize', 18);
%axis off;                          % 彻底关闭坐标轴显示
%axis equal;                        % 保持比例
%view(3);                           % 3D视角
%camlight; lighting gouraud;        % 添加光照，使圆柱更立体
box on;