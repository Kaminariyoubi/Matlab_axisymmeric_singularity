%% ================= Time step convergence test =================

% Please run main.m at first

rootDir = fileparts(mfilename('fullpath'));
addpath(fullfile(rootDir, 'src'));
addpath(fullfile(rootDir, 'functions'));

fprintf('=== Starting Time Step Convergence Verification ===\n');
tic;

params = config();

% 1. Parameters
n_levels = 4;               
r_ref = 2;
p_theory = 1;
est_ratio = 0:0.2:0.8;      
n_checks = length(est_ratio);

% Pre allocated storage space (using dual layer Cell: {checkpoint} {level})
gamma_sol = cell(n_checks, n_levels);
omega_sol = cell(n_checks, n_levels);
dt_vals   = zeros(n_levels, 1);
T_vals    = zeros(n_levels, 1);

% Cycle calculation of numerical solutions under different Δt values
for i = 1:n_levels-1  % i = 1, 2, 3
    params.dt1 = params.dtconv1 * (r_ref^(1-i));
    params.dt2 = params.dtconv2 * (r_ref^(1-i));
    dt_vals(i+1) = params.dt1;
    
    fprintf('\n[Level %d] dt1=%.2e, dt2=%.2e ... ', i, params.dt1, params.dt2);
    
    % Call the solver
    [gamma_conv2, gamma_conv3, Tg] = compute_gamma(params);
    [omega_conv2, omega_conv3, To] = compute_omega(params, gamma_conv2, gamma_conv3);
    T_vals(i+1) = To;
    
    % Calculate the index of all detection points at the current level
    N_total = size(gamma_conv3, 1);
    for c = 1:n_checks
        % Calculate the index of the detection point at the current level
        idx = round(est_ratio(c) * N_total) + 1;
        if idx > N_total, idx = N_total; end
        if idx < 1, idx = 1; end
        
        % Store in a double-layer cell
        gamma_sol{c, i+1} = gamma_conv3(idx, :);
        omega_sol{c, i+1} = omega_conv3(idx, :);
    end
    
    fprintf('Finished. Total time T=%.4f, N_total=%d\n', To, N_total);
end

fprintf('\n=== Analyzing Convergence at Multiple Checkpoints ===\n');

n_used = 3; 
dt_active = dt_vals(2:4);

p_gamma = zeros(n_checks, 1);
p_omega = zeros(n_checks, 1);
err_gamma = zeros(n_used, n_checks);
err_omega = zeros(n_used, n_checks);
GCI_gamma = zeros(n_checks, 1);
GCI_omega = zeros(n_checks, 1);

figure('Position', [100, 100, 800, 450]); hold on; grid on;
colors = lines(n_checks);

for c = 1:n_checks
    fprintf('\n--- Checkpoint %.0f%% ---\n', est_ratio(c)*100);
    
    % Extract the solutions of the current detection point at all levels
    g_data = zeros(size(gamma_sol{c, 2}, 2), n_used);  % Nx × 3
    o_data = zeros(size(omega_sol{c, 2}, 2), n_used);
    
    for lvl = 1:n_used
        % Extract data from double-layer cells
        row_g = gamma_sol{c, lvl+1};
        row_o = omega_sol{c, lvl+1};
        
        % NaN filter
        if any(isnan(row_g))
            valid = find(~any(isnan(gamma_sol{c, 2:lvl+1}), 2));
            if ~isempty(valid), row_g = gamma_sol{c, valid(end)+1}; end
        end
        if any(isnan(row_o))
            valid = find(~any(isnan(omega_sol{c, 2:lvl+1}), 2));
            if ~isempty(valid), row_o = omega_sol{c, valid(end)+1}; end
        end
        
        g_data(:, lvl) = row_g';
        o_data(:, lvl) = row_o';
    end
    
    % Calculate the difference in L2 norm between adjacent levels
    d_g12 = sqrt(sum((g_data(:,1) - g_data(:,2)).^2));
    d_g23 = sqrt(sum((g_data(:,2) - g_data(:,3)).^2));
    d_o12 = sqrt(sum((o_data(:,1) - o_data(:,2)).^2));
    d_o23 = sqrt(sum((o_data(:,2) - o_data(:,3)).^2));
    
    % Observation convergence order
    if d_g23 > 1e-12 && d_g12 > 1e-12
        p_gamma(c) = log(d_g12 / d_g23) / log(r_ref);
    else
        p_gamma(c) = NaN;
    end
    if d_o23 > 1e-12 && d_o12 > 1e-12
        p_omega(c) = log(d_o12 / d_o23) / log(r_ref);
    else
        p_omega(c) = NaN;
    end
    
    fprintf('Observed p (gamma): %.3f | Observed p (omega): %.3f\n', p_gamma(c), p_omega(c));
    
    % Richardson extrapolation and error estimation
    if ~isnan(p_gamma(c))
        pg = p_gamma(c);
        g_ext = (r_ref^pg * g_data(:,3) - g_data(:,2)) / (r_ref^pg - 1);
        err_gamma(:, c) = sqrt(sum((g_data - g_ext).^2));
        rel_err_g23 = d_g23 / (sqrt(sum(g_data(:,3).^2)) + eps);
        GCI_gamma(c) = 1.25 * (rel_err_g23 / (r_ref^pg - 1)) * 100;
    end
    
    if ~isnan(p_omega(c))
        po = p_omega(c);
        o_ext = (r_ref^po * o_data(:,3) - o_data(:,2)) / (r_ref^po - 1);
        err_omega(:, c) = sqrt(sum((o_data - o_ext).^2));
        rel_err_o23 = d_o23 / (sqrt(sum(o_data(:,3).^2)) + eps);
        GCI_omega(c) = 1.25 * (rel_err_o23 / (r_ref^po - 1)) * 100;
    end
    
    fprintf('GCI (gamma): %.3f %% | GCI (omega): %.3f %%\n', GCI_gamma(c), GCI_omega(c));
    
    % Plot
    if ~isnan(p_gamma(c))
        loglog(dt_active, err_gamma(:, c), '-o', 'Color', colors(c,:), ...
            'LineWidth', 2, 'MarkerSize', 7, ...
            'DisplayName', sprintf('gamma @ %.0f%% T', est_ratio(c)*100));
    end
end

% Draw theoretical slope reference line
valid_idx = find(~isnan(p_gamma), 1, 'first');
if ~isempty(valid_idx)
    p_ref = p_gamma(valid_idx);
    slope_ref = err_gamma(1, valid_idx) * (dt_active/dt_active(1)).^p_ref;
    loglog(dt_active, slope_ref, '--k', 'LineWidth', 1.5, ...
        'DisplayName', sprintf('Theoretical Slope p=%.1f', p_theory));
end

xlabel('\Delta t', 'FontSize', 12);
ylabel('L_2 Error vs Richardson Extrapolation', 'FontSize', 12);
title('Multi-Checkpoint Time Step Convergence Study', 'FontSize', 14);
legend('Location', 'best', 'FontSize', 10);
hold off;

fprintf('\n=== Verification Summary ===\n');
fprintf('Checkpoints: ');
for c = 1:n_checks, fprintf('%.0f%% ', est_ratio(c)*100); end
fprintf('\n');

fprintf('GCI (gamma): ');
for c = 1:n_checks, fprintf('%.3f%% ', GCI_gamma(c)); end
fprintf('\n');

fprintf('GCI (omega): ');
for c = 1:n_checks, fprintf('%.3f%% ', GCI_omega(c)); end
fprintf('\n');

fprintf('Completed in %.2f seconds.\n', toc);

%% ================= Comparison between _S and _gamma+_omega =================

plot(errT, log10(errgm), '--k', 'LineWidth', 1.5, 'DisplayName', sprintf('Error between gamma'), 'Color', 'magenta');
hold on
plot(errT, log10(errwm), '--k', 'LineWidth', 1.5, 'DisplayName', sprintf('Error between omega'), 'Color', 'cyan');
xlabel('t', 'FontSize', 12);
ylabel('log_{10}|1 - f_S/f_{ode}|', 'FontSize', 12);
title('Multi-Checkpoint Comparison', 'FontSize', 14);
legend('Location', 'best', 'FontSize', 10);