%% 显式逆函数法求解 r0(t) = gamma0^{-1}( ddS/(2dS^2 - S*ddS) )
% 依赖工作区: params, centralDiff, convergeS

fprintf('⏳ 计算 S(t) 及其导数...\n');
dt_val = params.dt2;
[y1, ~, ~, Ts1] = convergeS(params.gamma0, params.r, params.R, dt_val, params.step1, 0);
S1   = -1/min(params.gamma0(:)) * (1 - exp(y1));
dS1  = centralDiff(S1, dt_val);
ddS1 = centralDiff(dS1, dt_val);

fprintf('⏳ 显式计算 r0(t)...\n');

% 1. 计算目标值 f(t) = ddS / (2dS^2 - S*ddS)
denom = 2*dS1.^2 - S1.*ddS1;
f_t = ddS1 ./ denom;
f_t(~isfinite(f_t)) = NaN; % 屏蔽分母为零或NaN的不稳定点

% 2. 准备逆函数插值数据 (强制一维)
g_vec = params.gamma0(:);
r_vec = params.r(:);

% 3. 单调性保护 (interp1 要求自变量严格单调)
if ~issorted(g_vec) && ~issorted(g_vec, 'descend')
    warning('params.gamma0 非单调，已自动排序以保证逆函数唯一性。');
    [g_vec, idx] = sort(g_vec);
    r_vec = r_vec(idx);
end

% 4. 核心：一行代码完成逆函数求值 (完全向量化)
% interp1(Y, X, Yq) 数学等价于 X = f^{-1}(Yq)
r0_list = interp1(g_vec, r_vec, f_t, 'pchip');

% 5. 可视化
figure('Color','w', 'Position',[100,100,800,500]);
plot(Ts1, r0_list, 'b-', 'LineWidth', 2.5);
hold on; yline(0, 'k--', 'LineWidth', 1);
xlabel('Time t', 'FontSize', 16, 'FontName', 'Times New Roman');
ylabel('r_0(t)', 'FontSize', 16, 'FontName', 'Times New Roman');
title('r_0(t) = \gamma_0^{-1}\left( \frac{\ddot{S}}{2\dot{S}^2 - S\ddot{S}} \right)', ...
      'FontSize', 18, 'FontName', 'Times New Roman', 'Interpreter', 'latex');
grid on; box on;
set(gca, 'FontSize', 14, 'FontName', 'Times New Roman', 'LineWidth', 1.2);

fprintf('✅ 计算完成。r0(t) 已保存在变量 r0_list 中。\n');